#ifndef CONFIGDOC_H
#define CONFIGDOC_H

class DocIntf;

void addConfigDocs(DocIntf *doc);

#endif

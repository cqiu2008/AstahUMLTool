// objective: test \brief and \file command
// check: 008__brief_8c.xml
/** \file
 *  \brief A brief description.
 * 
 *  More details.
 */

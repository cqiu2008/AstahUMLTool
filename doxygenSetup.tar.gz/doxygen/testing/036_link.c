// objective: test \link command
// check: 036__link_8c.xml

/** \file 
 *  See \link func() the function\endlink for more info.
 *  See the \link Test test\endlink class.
 */

/** A function
 */
void func(int p);

/** A test */
class Test
{
};

// objective: test underlying type and strongness for an enum
// check: 073__typed__enum_8cpp.xml

/** \file */

/** @brief A strongly-typed enum */
enum class E: unsigned short {};
